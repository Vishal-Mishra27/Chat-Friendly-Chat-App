import React from "react";
function UserDashboard(){
    return(
        <>
        <span>This is user Dashboard</span>
        </>
    )
}
export default UserDashboard;